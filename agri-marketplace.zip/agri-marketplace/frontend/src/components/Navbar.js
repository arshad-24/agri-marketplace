import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../utils/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <Link to="/" className="logo">🌾 AgriConnect</Link>
      <div className="nav-links">
        <Link to="/products">Marketplace</Link>
        {user ? (
          <>
            {user.role === 'farmer' && <Link to="/dashboard/farmer">My Listings</Link>}
            {user.role === 'buyer' && <Link to="/dashboard/buyer">My Orders</Link>}
            <span className="user-greeting">Hi, {user.name}</span>
            <button onClick={handleLogout} className="btn-logout">Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register" className="btn-register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
