import React, { useEffect, useState } from 'react';
import { getMyOrders } from '../utils/api';

const STATUS_COLORS = {
  pending: '#f57c00',
  confirmed: '#1976d2',
  shipped: '#7b1fa2',
  delivered: '#2d7a3a',
  cancelled: '#c62828',
};

const BuyerDashboard = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyOrders()
      .then(({ data }) => setOrders(data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const totalSpent = orders.filter((o) => o.status !== 'cancelled').reduce((s, o) => s + parseFloat(o.total_price), 0);

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '32px 24px' }}>
      <h1 style={{ marginBottom: 24 }}>🛒 My Orders</h1>

      <div style={{ display: 'flex', gap: 16, marginBottom: 28 }}>
        {[
          { label: 'Total Orders', value: orders.length },
          { label: 'Total Spent', value: `₹${totalSpent.toFixed(0)}` },
          { label: 'Delivered', value: orders.filter((o) => o.status === 'delivered').length },
        ].map(({ label, value }) => (
          <div key={label} style={{ flex: 1, background: 'white', borderRadius: 10, padding: '18px 20px', boxShadow: '0 2px 8px rgba(0,0,0,0.07)', textAlign: 'center' }}>
            <div style={{ fontSize: '1.6rem', fontWeight: 700, color: '#2d7a3a' }}>{value}</div>
            <div style={{ fontSize: '0.8rem', color: '#888', marginTop: 4 }}>{label}</div>
          </div>
        ))}
      </div>

      {loading ? <p>Loading orders...</p> : orders.length === 0 ? (
        <p style={{ color: '#888', textAlign: 'center', padding: 60 }}>No orders yet. Browse the <a href="/products" style={{ color: '#2d7a3a' }}>marketplace</a>!</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {orders.map((o) => (
            <div key={o.id} style={{ background: 'white', padding: '18px 22px', borderRadius: 10, boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <strong style={{ fontSize: '1rem' }}>{o.product_name}</strong>
                  <p style={{ color: '#666', fontSize: '0.85rem', marginTop: 4 }}>
                    {o.quantity} {o.unit} · Sold by {o.farmer_name}
                  </p>
                  <p style={{ color: '#888', fontSize: '0.8rem' }}>{new Date(o.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 700, fontSize: '1.1rem' }}>₹{parseFloat(o.total_price).toFixed(2)}</div>
                  <span style={{ fontSize: '0.75rem', padding: '3px 10px', borderRadius: 12, background: STATUS_COLORS[o.status] + '22', color: STATUS_COLORS[o.status], fontWeight: 600, marginTop: 6, display: 'inline-block' }}>
                    {o.status.charAt(0).toUpperCase() + o.status.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BuyerDashboard;
