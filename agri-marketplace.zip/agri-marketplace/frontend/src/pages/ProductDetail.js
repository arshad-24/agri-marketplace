import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { getProduct, getPriceHistory, placeOrder } from '../utils/api';
import { useAuth } from '../utils/AuthContext';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [product, setProduct] = useState(null);
  const [priceHistory, setPriceHistory] = useState([]);
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [prodRes, priceRes] = await Promise.all([getProduct(id), getPriceHistory(id)]);
        setProduct(prodRes.data);
        setPriceHistory(
          priceRes.data.map((p) => ({
            date: new Date(p.recorded_at).toLocaleDateString(),
            price: parseFloat(p.price),
          }))
        );
      } catch {
        navigate('/products');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const handleOrder = async () => {
    if (!user) return navigate('/login');
    try {
      const res = await placeOrder({ product_id: id, quantity });
      setMessage(`✅ Order placed! Total: ₹${res.data.total_price}`);
    } catch (err) {
      setMessage(`❌ ${err.response?.data?.message || 'Order failed'}`);
    }
  };

  if (loading) return <div className="loading">Loading product...</div>;
  if (!product) return null;

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '32px 24px' }}>
      <button onClick={() => navigate(-1)} style={{ marginBottom: 24, background: 'none', border: '1px solid #ddd', padding: '8px 16px', borderRadius: 8, cursor: 'pointer' }}>
        ← Back
      </button>

      <div style={{ background: 'white', borderRadius: 12, padding: 32, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
        <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 240 }}>
            <div style={{ background: '#e8f5e9', borderRadius: 10, height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '5rem', marginBottom: 16 }}>🌾</div>
            <span style={{ fontSize: '0.75rem', background: '#e8f5e9', color: '#2d7a3a', padding: '2px 10px', borderRadius: 12 }}>{product.category}</span>
            <h2 style={{ marginTop: 10, fontSize: '1.6rem' }}>{product.name}</h2>
            <p style={{ color: '#666', marginTop: 6 }}>Sold by <strong>{product.farmer_name}</strong></p>
            <p style={{ color: '#888', fontSize: '0.85rem' }}>📍 {product.farmer_location}</p>
            {product.description && <p style={{ marginTop: 12, color: '#444', lineHeight: 1.6 }}>{product.description}</p>}
          </div>

          <div style={{ width: 240 }}>
            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#2d7a3a' }}>₹{product.price_per_unit}/{product.unit}</div>
            <p style={{ color: '#666', margin: '8px 0 20px' }}>{product.quantity_available} units available</p>

            {user?.role === 'buyer' && (
              <>
                <label style={{ display: 'block', marginBottom: 6, fontSize: '0.9rem', fontWeight: 600 }}>Quantity ({product.unit})</label>
                <input
                  type="number"
                  min={1}
                  max={product.quantity_available}
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  style={{ width: '100%', padding: '10px', border: '1px solid #ddd', borderRadius: 8, fontSize: '1rem', marginBottom: 12 }}
                />
                <div style={{ color: '#2d7a3a', fontWeight: 600, marginBottom: 12 }}>
                  Total: ₹{(product.price_per_unit * quantity).toFixed(2)}
                </div>
                <button
                  onClick={handleOrder}
                  style={{ width: '100%', padding: 12, background: '#2d7a3a', color: 'white', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: '1rem', cursor: 'pointer' }}
                >
                  Place Order
                </button>
                {message && (
                  <div style={{ marginTop: 12, padding: '10px 14px', background: message.startsWith('✅') ? '#e8f5e9' : '#fdecea', borderRadius: 8, fontSize: '0.9rem' }}>
                    {message}
                  </div>
                )}
              </>
            )}
            {!user && (
              <button onClick={() => navigate('/login')} style={{ width: '100%', padding: 12, background: '#2d7a3a', color: 'white', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600 }}>
                Login to Buy
              </button>
            )}
          </div>
        </div>

        {priceHistory.length > 1 && (
          <div style={{ marginTop: 32 }}>
            <h3 style={{ marginBottom: 16 }}>📈 Price History</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={priceHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(v) => `₹${v}`} />
                <Line type="monotone" dataKey="price" stroke="#2d7a3a" strokeWidth={2} dot={{ fill: '#2d7a3a' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
