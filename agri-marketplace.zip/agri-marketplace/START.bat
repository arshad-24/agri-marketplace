@echo off
title AgriConnect - Setup and Run
color 0A

echo.
echo  ==========================================
echo    AGRICONNECT - Agriculture Marketplace
echo  ==========================================
echo.

:: ---- Check Node.js ----
node -v >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js is NOT installed.
    echo Please download and install it from: https://nodejs.org
    echo After installing, run this file again.
    pause
    exit
)
echo [OK] Node.js found

:: ---- Check MySQL ----
mysql --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] MySQL is NOT installed or not in PATH.
    echo Please install MySQL from: https://dev.mysql.com/downloads/installer/
    pause
    exit
)
echo [OK] MySQL found

:: ---- Ask MySQL password ----
echo.
set /p DBPASS=Enter your MySQL root password: 

:: ---- Create .env file ----
echo DB_HOST=localhost > backend\.env
echo DB_USER=root >> backend\.env
echo DB_PASSWORD=%DBPASS% >> backend\.env
echo DB_NAME=agri_marketplace >> backend\.env
echo JWT_SECRET=agriconnect_secret_key_2025 >> backend\.env
echo PORT=5000 >> backend\.env
echo [OK] .env file created

:: ---- Setup Database ----
echo.
echo [STEP] Setting up database...
mysql -u root -p%DBPASS% < database\schema.sql
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Database setup failed. Check your MySQL password.
    pause
    exit
)
echo [OK] Database ready

:: ---- Install Backend ----
echo.
echo [STEP] Installing backend packages (this takes 1-2 mins)...
cd backend
call npm install
cd ..
echo [OK] Backend packages installed

:: ---- Install Frontend ----
echo.
echo [STEP] Installing frontend packages (this takes 2-3 mins)...
cd frontend
call npm install
cd ..
echo [OK] Frontend packages installed

:: ---- Start Backend in new window ----
echo.
echo [STEP] Starting backend server...
start "AgriConnect Backend" cmd /k "cd /d %~dp0backend && npm run dev"
timeout /t 3 /nobreak >nul

:: ---- Start Frontend in new window ----
echo [STEP] Starting frontend...
start "AgriConnect Frontend" cmd /k "cd /d %~dp0frontend && npm start"

echo.
echo  ==========================================
echo   App is starting! 
echo   Browser will open at http://localhost:3000
echo   Keep both black windows open.
echo  ==========================================
echo.
pause
