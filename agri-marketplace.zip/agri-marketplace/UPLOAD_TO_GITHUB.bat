@echo off
title Upload to GitHub
color 0E

echo.
echo  ==========================================
echo    UPLOAD AgriConnect to GitHub
echo  ==========================================
echo.

:: Check git
git --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Git is not installed.
    echo Download from: https://git-scm.com
    pause
    exit
)

echo Enter your GitHub details:
echo.
set /p USERNAME=Your GitHub username: 
set /p EMAIL=Your GitHub email: 
set /p REPONAME=Repository name (e.g. agri-marketplace): 

:: Configure git
git config --global user.name "%USERNAME%"
git config --global user.email "%EMAIL%"

:: Init and push
git init
git add .
git commit -m "Initial commit: AgriConnect full-stack agriculture marketplace"
git branch -M main
git remote add origin https://github.com/%USERNAME%/%REPONAME%.git
git push -u origin main

echo.
echo  ==========================================
echo   SUCCESS! Visit your repo at:
echo   https://github.com/%USERNAME%/%REPONAME%
echo  ==========================================
echo.
pause
