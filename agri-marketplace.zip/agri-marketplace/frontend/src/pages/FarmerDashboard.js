import React, { useEffect, useState } from 'react';
import { getProducts, createProduct } from '../utils/api';
import { useAuth } from '../utils/AuthContext';

const CATEGORIES = ['Vegetables', 'Fruits', 'Grains', 'Dairy', 'Spices', 'Other'];

const FarmerDashboard = () => {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', category: 'Vegetables', description: '', price_per_unit: '', unit: 'kg', quantity_available: '' });
  const [message, setMessage] = useState('');

  const fetchMyProducts = async () => {
    try {
      const { data } = await getProducts();
      setProducts(data.filter((p) => p.farmer_name === user.name));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchMyProducts(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createProduct(form);
      setMessage('✅ Product listed successfully!');
      setShowForm(false);
      setForm({ name: '', category: 'Vegetables', description: '', price_per_unit: '', unit: 'kg', quantity_available: '' });
      fetchMyProducts();
    } catch (err) {
      setMessage(`❌ ${err.response?.data?.message || 'Failed to list product'}`);
    }
  };

  const inputStyle = { width: '100%', padding: '10px 12px', border: '1px solid #ddd', borderRadius: 8, fontSize: '0.95rem', marginBottom: 12 };

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
        <h1>🌾 Farmer Dashboard</h1>
        <button onClick={() => setShowForm(!showForm)} style={{ background: '#2d7a3a', color: 'white', border: 'none', padding: '10px 22px', borderRadius: 8, cursor: 'pointer', fontWeight: 600 }}>
          {showForm ? 'Cancel' : '+ New Listing'}
        </button>
      </div>

      {message && <div style={{ padding: '10px 16px', background: '#e8f5e9', borderRadius: 8, marginBottom: 20 }}>{message}</div>}

      {showForm && (
        <div style={{ background: 'white', padding: 28, borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.08)', marginBottom: 28 }}>
          <h3 style={{ marginBottom: 20 }}>List a New Product</h3>
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <input style={inputStyle} placeholder="Product name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              <select style={inputStyle} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
              <input style={inputStyle} placeholder="Price per unit (₹)" type="number" value={form.price_per_unit} onChange={(e) => setForm({ ...form, price_per_unit: e.target.value })} required />
              <div style={{ display: 'flex', gap: 8 }}>
                <input style={{ ...inputStyle, flex: 1 }} placeholder="Quantity" type="number" value={form.quantity_available} onChange={(e) => setForm({ ...form, quantity_available: e.target.value })} required />
                <select style={{ ...inputStyle, width: 80 }} value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}>
                  {['kg', 'g', 'litre', 'piece', 'dozen', 'quintal'].map((u) => <option key={u}>{u}</option>)}
                </select>
              </div>
            </div>
            <textarea style={{ ...inputStyle, height: 80, resize: 'vertical' }} placeholder="Description (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            <button type="submit" style={{ background: '#2d7a3a', color: 'white', border: 'none', padding: '12px 28px', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: '0.95rem' }}>
              Submit Listing
            </button>
          </form>
        </div>
      )}

      <h2 style={{ marginBottom: 16 }}>Your Active Listings ({products.length})</h2>
      {products.length === 0 ? (
        <p style={{ color: '#888', textAlign: 'center', padding: 40 }}>No listings yet. Click "New Listing" to start selling.</p>
      ) : (
        <div style={{ display: 'grid', gap: 14 }}>
          {products.map((p) => (
            <div key={p.id} style={{ background: 'white', padding: '18px 22px', borderRadius: 10, boxShadow: '0 1px 6px rgba(0,0,0,0.06)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <strong>{p.name}</strong>
                <span style={{ marginLeft: 10, fontSize: '0.75rem', background: '#e8f5e9', color: '#2d7a3a', padding: '2px 8px', borderRadius: 12 }}>{p.category}</span>
                <p style={{ color: '#666', fontSize: '0.85rem', marginTop: 4 }}>{p.quantity_available} {p.unit} available</p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '1.2rem', fontWeight: 700, color: '#2d7a3a' }}>₹{p.price_per_unit}/{p.unit}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FarmerDashboard;
