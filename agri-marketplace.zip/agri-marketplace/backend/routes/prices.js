const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET /api/prices/:productId — Price history for a product
router.get('/:productId', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT price, recorded_at FROM price_history WHERE product_id = ? ORDER BY recorded_at ASC',
      [req.params.productId]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
