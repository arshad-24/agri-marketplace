import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { registerUser } from '../utils/api';
import { useAuth } from '../utils/AuthContext';

const Register = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'buyer', phone: '', location: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await registerUser(form);
      login({ name: form.name, email: form.email, role: form.role }, data.token);
      navigate(form.role === 'farmer' ? '/dashboard/farmer' : '/products');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Join AgriConnect 🌱</h2>
        <p>Create your account to get started</p>
        {error && <div className="error-msg">{error}</div>}
        <form onSubmit={handleSubmit}>
          <input name="name" placeholder="Full Name" value={form.name} onChange={handleChange} required />
          <input name="email" type="email" placeholder="Email address" value={form.email} onChange={handleChange} required />
          <input name="password" type="password" placeholder="Password (min 6 chars)" value={form.password} onChange={handleChange} required minLength={6} />
          <input name="phone" placeholder="Phone number" value={form.phone} onChange={handleChange} />
          <input name="location" placeholder="District / City" value={form.location} onChange={handleChange} />
          <select name="role" value={form.role} onChange={handleChange} style={{ padding: '12px 14px', border: '1px solid #ddd', borderRadius: 8, marginBottom: 14, width: '100%', fontSize: '1rem' }}>
            <option value="buyer">I'm a Buyer</option>
            <option value="farmer">I'm a Farmer</option>
          </select>
          <button type="submit" disabled={loading}>
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>
        <p className="auth-switch">
          Already have an account? <Link to="/login">Login here</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
