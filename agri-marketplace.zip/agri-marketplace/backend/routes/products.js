const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { protect, isFarmer } = require('../middleware/authMiddleware');

// GET /api/products — List all active products
router.get('/', async (req, res) => {
  try {
    const { category, search } = req.query;
    let query = `
      SELECT p.*, u.name AS farmer_name, u.location AS farmer_location
      FROM products p
      JOIN users u ON p.farmer_id = u.id
      WHERE p.is_active = TRUE
    `;
    const params = [];

    if (category) {
      query += ' AND p.category = ?';
      params.push(category);
    }
    if (search) {
      query += ' AND p.name LIKE ?';
      params.push(`%${search}%`);
    }
    query += ' ORDER BY p.created_at DESC';

    const [products] = await db.query(query, params);
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// GET /api/products/:id — Single product
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT p.*, u.name AS farmer_name, u.phone AS farmer_phone, u.location AS farmer_location
       FROM products p JOIN users u ON p.farmer_id = u.id
       WHERE p.id = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Product not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// POST /api/products — Farmer creates a listing
router.post('/', protect, isFarmer, async (req, res) => {
  const { name, category, description, price_per_unit, unit, quantity_available, image_url } = req.body;
  if (!name || !price_per_unit || !quantity_available) {
    return res.status(400).json({ message: 'Name, price, and quantity are required' });
  }

  try {
    const [result] = await db.query(
      `INSERT INTO products (farmer_id, name, category, description, price_per_unit, unit, quantity_available, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, name, category, description, price_per_unit, unit || 'kg', quantity_available, image_url]
    );
    // Log to price history
    await db.query('INSERT INTO price_history (product_id, price) VALUES (?, ?)', [result.insertId, price_per_unit]);
    res.status(201).json({ message: 'Product listed successfully', productId: result.insertId });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// PUT /api/products/:id — Farmer updates listing
router.put('/:id', protect, isFarmer, async (req, res) => {
  const { price_per_unit, quantity_available, is_active } = req.body;
  try {
    const [rows] = await db.query('SELECT * FROM products WHERE id = ? AND farmer_id = ?', [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Product not found or unauthorized' });

    await db.query(
      'UPDATE products SET price_per_unit = ?, quantity_available = ?, is_active = ? WHERE id = ?',
      [price_per_unit ?? rows[0].price_per_unit, quantity_available ?? rows[0].quantity_available, is_active ?? rows[0].is_active, req.params.id]
    );

    if (price_per_unit && price_per_unit !== rows[0].price_per_unit) {
      await db.query('INSERT INTO price_history (product_id, price) VALUES (?, ?)', [req.params.id, price_per_unit]);
    }

    res.json({ message: 'Product updated successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
