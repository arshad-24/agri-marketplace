import React from 'react';
import { Link } from 'react-router-dom';

const ProductCard = ({ product }) => {
  return (
    <div className="product-card">
      <div className="product-image">
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} />
        ) : (
          <div className="placeholder-image">🌾</div>
        )}
      </div>
      <div className="product-info">
        <span className="product-category">{product.category || 'General'}</span>
        <h3>{product.name}</h3>
        <p className="farmer-name">by {product.farmer_name}</p>
        <p className="location">📍 {product.farmer_location}</p>
        <div className="product-footer">
          <span className="price">₹{product.price_per_unit}/{product.unit}</span>
          <span className="qty">{product.quantity_available} available</span>
        </div>
        <Link to={`/products/${product.id}`} className="btn-view">View Details</Link>
      </div>
    </div>
  );
};

export default ProductCard;
