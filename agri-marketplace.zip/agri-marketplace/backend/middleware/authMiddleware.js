const jwt = require('jsonwebtoken');

const protect = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Not authorized, no token' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};

const isFarmer = (req, res, next) => {
  if (req.user?.role !== 'farmer') {
    return res.status(403).json({ message: 'Access denied: Farmers only' });
  }
  next();
};

const isBuyer = (req, res, next) => {
  if (req.user?.role !== 'buyer') {
    return res.status(403).json({ message: 'Access denied: Buyers only' });
  }
  next();
};

module.exports = { protect, isFarmer, isBuyer };
