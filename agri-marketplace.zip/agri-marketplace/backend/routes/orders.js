const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { protect, isBuyer } = require('../middleware/authMiddleware');

// POST /api/orders — Place an order
router.post('/', protect, isBuyer, async (req, res) => {
  const { product_id, quantity } = req.body;
  if (!product_id || !quantity || quantity <= 0) {
    return res.status(400).json({ message: 'Valid product and quantity required' });
  }

  try {
    const [products] = await db.query('SELECT * FROM products WHERE id = ? AND is_active = TRUE', [product_id]);
    if (products.length === 0) return res.status(404).json({ message: 'Product not available' });

    const product = products[0];
    if (product.quantity_available < quantity) {
      return res.status(400).json({ message: `Only ${product.quantity_available} units available` });
    }

    const total_price = product.price_per_unit * quantity;

    const [result] = await db.query(
      'INSERT INTO orders (buyer_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)',
      [req.user.id, product_id, quantity, total_price]
    );

    // Reduce stock
    await db.query('UPDATE products SET quantity_available = quantity_available - ? WHERE id = ?', [quantity, product_id]);

    res.status(201).json({ message: 'Order placed successfully', orderId: result.insertId, total_price });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// GET /api/orders/my — Buyer's order history
router.get('/my', protect, async (req, res) => {
  try {
    const [orders] = await db.query(
      `SELECT o.*, p.name AS product_name, p.unit, u.name AS farmer_name
       FROM orders o
       JOIN products p ON o.product_id = p.id
       JOIN users u ON p.farmer_id = u.id
       WHERE o.buyer_id = ?
       ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// PUT /api/orders/:id/status — Farmer updates order status
router.put('/:id/status', protect, async (req, res) => {
  const { status } = req.body;
  const validStatuses = ['confirmed', 'shipped', 'delivered', 'cancelled'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ message: 'Invalid status' });
  }

  try {
    await db.query('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ message: `Order marked as ${status}` });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
